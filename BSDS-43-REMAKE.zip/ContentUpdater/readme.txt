How to use:

put your files in ContentUpdater/Content

run ContentUpdater/Updater.py

after its done run ContentUpdater/Server.py

if you managed to deleted it by accident here what lastversion.txt should contains

43.229.1...fa79d7e040bd31e68c88c0238fd4777086cf534c